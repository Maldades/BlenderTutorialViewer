"""Add-on properties, stored in ``Scene.bvp``."""
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty


class BVPProperties(bpy.types.PropertyGroup):
    source_type: EnumProperty(
        name="Source",
        items=[
            ("URL", "Internet URL", "A YouTube or other site video, or a direct link"),
            ("LOCAL", "Local file", "A video file on your computer"),
        ],
        default="URL",
    )
    url: StringProperty(
        name="URL",
        description="Video link (YouTube, Vimeo, direct link, etc.)",
        default="",
    )
    local_path: StringProperty(
        name="File",
        description="Path to a local video file",
        subtype="FILE_PATH",
        default="",
    )
    keep_local: BoolProperty(
        name="Keep local copy",
        description="Save the downloaded video to a folder instead of a temp dir",
        default=False,
    )
    dest_dir: StringProperty(
        name="Folder",
        description="Folder to save the downloaded video into",
        subtype="DIR_PATH",
        default="",
    )
    status: StringProperty(name="Status", default="")
    progress: FloatProperty(
        name="Progress", default=0.0, min=0.0, max=100.0, subtype="PERCENTAGE"
    )
    resolved_filepath: StringProperty(default="")
