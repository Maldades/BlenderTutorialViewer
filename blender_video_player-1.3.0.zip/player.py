"""Mounting and playback of the video inside Blender.

Design (verified live in Blender 5.1):

- **Video**: the file is loaded as a ``MOVIE`` image datablock and shown in an
  **Image Editor**. That editor auto-fits the image and advances frames with the
  timeline (``image_user.use_auto_refresh``).
- **Audio**: a **sound strip** is added in the Video Sequence Editor, which plays
  during timeline playback (``screen.animation_play`` with
  ``sync_mode='AUDIO_SYNC'``), even when the VSE is not visible.

The VSE preview was ruled out because its 2D view cannot be reliably auto-fitted
from a script (it stays black).
"""
import bpy

#: Name prefix to identify elements created by this add-on.
STRIP_PREFIX = "BVP_"

#: Interval (s) of the auto-fit monitor.
_AUTOFIT_INTERVAL = 0.25
#: Last known size of each area, keyed by ``area.as_pointer()``.
_autofit_last_sizes = {}


def _strips(se):
    """Strip collection, compatible with 5.x (``strips``) and 4.x (``sequences``).

    ``or`` can't be used: an empty collection is "falsy".
    """
    if hasattr(se, "strips"):
        return se.strips
    return se.sequences


def ensure_sequence_editor(scene):
    if scene.sequence_editor is None:
        scene.sequence_editor_create()
    return scene.sequence_editor


def clear_video(scene):
    """Remove the sound strip and images created by this add-on."""
    se = scene.sequence_editor
    if se is not None:
        strips = _strips(se)
        for strip in list(strips):
            if strip.name.startswith(STRIP_PREFIX):
                strips.remove(strip)
    for image in list(bpy.data.images):
        if image.get("bvp_owned"):
            bpy.data.images.remove(image)


def add_video(scene, filepath, fps=None, replace=True):
    """Load ``filepath`` as a movie image + sound strip, and set up the scene.

    Returns ``(image, sound_or_None)``.
    """
    if replace:
        clear_video(scene)

    image = bpy.data.images.load(filepath, check_existing=False)
    if image.source != "MOVIE":
        # Force movie interpretation (in case the heuristic fails).
        try:
            image.source = "MOVIE"
        except (TypeError, ValueError):
            pass
    image["bvp_owned"] = True

    se = ensure_sequence_editor(scene)
    strips = _strips(se)
    sound = None
    try:
        sound = strips.new_sound(
            name=STRIP_PREFIX + "Audio", filepath=filepath, channel=1, frame_start=1
        )
    except (RuntimeError, TypeError):
        sound = None  # the file may have no audio track

    duration = image.frame_duration
    if not duration and sound is not None:
        duration = sound.frame_final_duration

    scene.frame_start = 1
    scene.frame_end = max(1, duration or 1)
    scene.frame_current = 1
    if fps:
        scene.render.fps = max(1, round(fps))
    scene.sync_mode = "AUDIO_SYNC"
    return image, sound


# --- Interface (requires a window; tested live) ---

def get_image_editor_area(screen):
    for area in screen.areas:
        if area.type == "IMAGE_EDITOR":
            return area
    return None


def open_player_area(context, image):
    """Open (or reuse) an Image Editor showing ``image``.

    If there is none, split the largest area. Returns the area, or ``None`` in
    background mode (no screen).
    """
    screen = getattr(context, "screen", None)
    if screen is None:
        return None

    area = get_image_editor_area(screen)
    if area is None:
        biggest = max(screen.areas, key=lambda a: a.width * a.height)
        before = set(screen.areas)
        with context.temp_override(area=biggest):
            bpy.ops.screen.area_split(direction="VERTICAL", factor=0.5)
        new_areas = [a for a in screen.areas if a not in before]
        area = new_areas[0] if new_areas else biggest
        area.type = "IMAGE_EDITOR"

    space = area.spaces.active
    space.image = image
    image_user = space.image_user
    image_user.frame_duration = image.frame_duration or 1
    image_user.frame_start = 1
    image_user.frame_offset = 0
    image_user.use_auto_refresh = True
    area.tag_redraw()
    return area


def is_playing(context):
    screen = getattr(context, "screen", None)
    return bool(screen and screen.is_animation_playing)


def toggle_play(context, area=None):
    """Toggle timeline playback (video + audio)."""
    screen = getattr(context, "screen", None)
    area = area or (get_image_editor_area(screen) if screen else None)
    if area is not None:
        with context.temp_override(area=area):
            bpy.ops.screen.animation_play()
    else:
        bpy.ops.screen.animation_play()


# --- Auto-fit on load and on area resize ---

def _iter_target_areas():
    """Yield ``(window, area)`` for each Image Editor showing our image."""
    wm = bpy.context.window_manager
    if wm is None:
        return
    for win in wm.windows:
        screen = win.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "IMAGE_EDITOR":
                continue
            space = area.spaces.active
            image = getattr(space, "image", None)
            if image is not None and image.get("bvp_owned"):
                yield win, area


def fit_view(area=None, window=None):
    """Fit the video in the add-on's Image Editor(s). Best-effort."""
    context = bpy.context
    if area is not None:
        pairs = [(window or getattr(context, "window", None), area)]
    else:
        pairs = list(_iter_target_areas())
    for win, target in pairs:
        if win is None or target is None:
            continue
        region = next((r for r in target.regions if r.type == "WINDOW"), None)
        if region is None:
            continue
        try:
            with context.temp_override(window=win, area=target, region=region):
                bpy.ops.image.view_all(fit_view=True)
        except Exception:  # noqa: BLE001 - best-effort
            pass


def _autofit_tick():
    """Poller: re-fit when the player area size changes."""
    found = False
    for win, area in _iter_target_areas():
        found = True
        key = area.as_pointer()
        size = (area.width, area.height)
        if _autofit_last_sizes.get(key) != size:
            _autofit_last_sizes[key] = size
            fit_view(area=area, window=win)
    if not found:
        _autofit_last_sizes.clear()
        return None  # no player: stop the monitor
    return _AUTOFIT_INTERVAL


def start_autofit_monitor():
    if not bpy.app.timers.is_registered(_autofit_tick):
        _autofit_last_sizes.clear()
        bpy.app.timers.register(_autofit_tick, first_interval=0.1)


def stop_autofit_monitor():
    if bpy.app.timers.is_registered(_autofit_tick):
        bpy.app.timers.unregister(_autofit_tick)
    _autofit_last_sizes.clear()
