"""Dependency management (yt-dlp and ffmpeg). Hybrid model.

- If the add-on is installed as an Extension (Blender 4.2+), the wheel declared in
  ``blender_manifest.toml`` is already on ``sys.path`` → ``import yt_dlp`` works.
- As a fallback (e.g. in development via a symlink), the bundled ``.whl`` is added
  to ``sys.path`` (pure-python wheels are importable via zipimport).
- ``update_ytdlp`` / ``install_ffmpeg`` install with pip into a local folder.
- ``find_ffmpeg`` locates ffmpeg (system or imageio-ffmpeg). On Windows ffmpeg is
  not bundled with the OS; the "Install ffmpeg" button brings ``imageio-ffmpeg``
  (per-platform binary) without leaving Blender.

Does not import ``bpy``: only the standard library.
"""
import importlib
import os
import shutil
import subprocess
import sys

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
WHEELS_DIR = os.path.join(ADDON_DIR, "wheels")
#: Folder where the install buttons put pip packages (takes priority).
UPDATE_DIR = os.path.join(ADDON_DIR, "_deps")

_UNSET = object()
#: Cache of the ffmpeg path (avoids recomputing on every panel redraw).
_ffmpeg_path = _UNSET


def _candidate_paths():
    paths = []
    if os.path.isdir(UPDATE_DIR):
        paths.append(UPDATE_DIR)
    if os.path.isdir(WHEELS_DIR):
        paths.append(WHEELS_DIR)
        for name in sorted(os.listdir(WHEELS_DIR)):
            if name.endswith(".whl"):
                paths.append(os.path.join(WHEELS_DIR, name))
    return paths


def _add_local_paths():
    for path in _candidate_paths():
        if path not in sys.path:
            sys.path.insert(0, path)


def ensure_ytdlp():
    """Return the importable ``yt_dlp`` module, or ``None`` if not available."""
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        pass
    _add_local_paths()
    importlib.invalidate_caches()
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        return None


def ytdlp_version():
    module = ensure_ytdlp()
    if module is None:
        return None
    try:
        return module.version.__version__
    except AttributeError:
        return "?"


def _blender_python_exe():
    """Path to Blender's embedded Python interpreter (to invoke pip).

    Covers Linux/macOS (``bin/python3.13``) and Windows (``bin/python.exe``).
    """
    ver = "python%d.%d" % sys.version_info[:2]
    names = [ver, "python3", "python"]
    for sub in ("bin", "Scripts", "."):
        for name in names:
            for candidate in (
                os.path.join(sys.prefix, sub, name),
                os.path.join(sys.prefix, sub, name + ".exe"),
            ):
                if os.path.isfile(candidate):
                    return candidate
    # Last resort: sys.executable (in Blender this is usually the binary itself,
    # so pip may not work; the error is reported to the user).
    return sys.executable


def _reload_ytdlp():
    _add_local_paths()
    importlib.invalidate_caches()
    for name in list(sys.modules):
        if name == "yt_dlp" or name.startswith("yt_dlp."):
            del sys.modules[name]


def _pip_install(package):
    """Install/upgrade ``package`` with pip into :data:`UPDATE_DIR`.

    :returns: ``(ok: bool, message: str)``.
    """
    python_exe = _blender_python_exe()
    try:
        os.makedirs(UPDATE_DIR, exist_ok=True)
    except OSError as exc:
        return False, f"Could not create deps folder: {exc}"

    # Make sure pip is available in Blender's Python.
    subprocess.run([python_exe, "-m", "ensurepip"], capture_output=True, text=True)

    try:
        result = subprocess.run(
            [
                python_exe, "-m", "pip", "install", "--upgrade",
                "--target", UPDATE_DIR, package,
            ],
            capture_output=True,
            text=True,
            timeout=600,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Failed to run pip: {exc}"

    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        return False, f"pip failed: {detail[-300:]}"
    return True, "ok"


def update_ytdlp():
    """Install/upgrade yt-dlp. Returns ``(ok, message)``."""
    ok, message = _pip_install("yt-dlp")
    if not ok:
        return False, message
    _reload_ytdlp()
    return True, f"yt-dlp updated to {ytdlp_version() or '?'}"


# --- ffmpeg (needed to merge YouTube video+audio; absent on Windows) ---

def _imageio_ffmpeg_exe():
    """Path to imageio-ffmpeg's ffmpeg if installed, else ``None``."""
    _add_local_paths()
    importlib.invalidate_caches()
    try:
        import imageio_ffmpeg
        path = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:  # noqa: BLE001 - not installed / no binary
        return None
    return path if path and os.path.isfile(path) else None


def find_ffmpeg(refresh=False):
    """Path to a usable ffmpeg (system first), or ``None``. Cached."""
    global _ffmpeg_path
    if _ffmpeg_path is not _UNSET and not refresh:
        return _ffmpeg_path
    _ffmpeg_path = shutil.which("ffmpeg") or _imageio_ffmpeg_exe()
    return _ffmpeg_path


def install_ffmpeg():
    """Install ``imageio-ffmpeg`` (per-platform binary) with pip.

    :returns: ``(ok: bool, message: str)``.
    """
    ok, message = _pip_install("imageio-ffmpeg")
    if not ok:
        return False, message
    path = find_ffmpeg(refresh=True)
    if path:
        return True, "ffmpeg installed"
    return False, "imageio-ffmpeg installed but binary not found"
