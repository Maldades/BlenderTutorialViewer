"""Classification and validation of video sources.

Pure logic, no ``bpy`` or ``yt_dlp`` dependency, so it can run under pytest
outside Blender.
"""
import glob
import os
import re

#: Recognized video container extensions for local files.
VIDEO_EXTENSIONS = frozenset(
    {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v", ".mpg", ".mpeg", ".flv", ".wmv"}
)

#: Pure-audio extensions a split download may leave next to the video file.
AUDIO_EXTENSIONS = frozenset({".m4a", ".aac", ".opus", ".ogg", ".oga", ".mp3"})

#: The '.fNNN' suffix ``downloader.OUTTMPL_SPLIT`` puts before the extension.
_SPLIT_SUFFIX = re.compile(r"\.f[\w+-]+")

_URL_PREFIXES = ("http://", "https://")


def classify_source(text):
    """Return ``"url"`` or ``"local"`` for the input string.

    Classification is purely syntactic: if it starts with ``http://`` or
    ``https://`` it is treated as a remote URL; otherwise as a local file path.
    It does not touch the filesystem.

    :raises ValueError: if the text is empty or whitespace only.
    """
    if text is None:
        raise ValueError("Source cannot be None")
    stripped = text.strip()
    if not stripped:
        raise ValueError("Source is empty")
    if stripped.lower().startswith(_URL_PREFIXES):
        return "url"
    return "local"


def is_probably_video_file(path):
    """Extension-based heuristic: does this look like a video file?"""
    _, ext = os.path.splitext(path)
    return ext.lower() in VIDEO_EXTENSIONS


def find_sibling_audio(path):
    """Audio file next to a split download ('X.f137.mp4' → 'X.f140.m4a').

    Downloads made without ffmpeg keep video and audio as two files sharing a
    stem plus an ``.fNNN`` format suffix. Given the video path, return its
    audio sibling, or ``None`` (also for regular, non-split filenames).
    """
    stem, _ = os.path.splitext(path)
    base, fmt_suffix = os.path.splitext(stem)
    if not _SPLIT_SUFFIX.fullmatch(fmt_suffix):
        return None
    for candidate in sorted(glob.glob(glob.escape(base) + ".f*")):
        if candidate == path:
            continue
        if os.path.splitext(candidate)[1].lower() in AUDIO_EXTENSIONS:
            return candidate
    return None
