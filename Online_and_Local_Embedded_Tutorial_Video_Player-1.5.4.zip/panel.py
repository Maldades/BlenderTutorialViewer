"""Add-on panels: N-sidebar 'Video' tab in the 3D viewport AND in the
Image Editor that plays the video (same controls, both places)."""
import bpy

from . import deps, player


class _BVPPanelDraw:
    """Shared UI; subclasses only pick the space the panel lives in."""

    bl_label = "Video Player"
    bl_region_type = "UI"
    bl_category = "Video"

    def draw(self, context):
        layout = self.layout
        props = context.scene.bvp

        layout.prop(props, "source_type", expand=True)

        if props.source_type == "URL":
            layout.prop(props, "url", text="", icon="URL")
            if not bpy.app.online_access:
                row = layout.row()
                row.label(text="Online access is disabled", icon="ERROR")
        else:
            layout.prop(props, "local_path", text="")

        layout.operator("bvp.load_video", icon="IMPORT")

        if 0.0 < props.progress < 100.0:
            layout.label(text=f"Downloading… {props.progress:.0f}%", icon="SORTTIME")
        elif props.status:
            layout.label(text=props.status, icon="INFO")

        layout.separator()
        row = layout.row(align=True)
        row.operator(
            "bvp.play_pause",
            icon="PAUSE" if player.is_playing() else "PLAY",
        )
        row.operator("bvp.seek", text="", icon="REW").delta = -10
        row.operator("bvp.seek", text="", icon="FF").delta = 10
        row.operator("bvp.unload_video", icon="TRASH", text="")
        if player.is_mounted():
            wm = context.window_manager
            # The video's own timeline (independent from the scene's).
            layout.prop(wm, "bvp_playhead", text="", slider=True)
            row = layout.row(align=True)
            row.label(text="", icon="PLAY_SOUND")
            row.prop(wm, "bvp_volume", text="", slider=True)
            layout.label(text=player.playback_status(), icon="TIME")

        if props.source_type == "URL":
            col = layout.column(align=True)
            col.separator()
            support = col.box()
            support.scale_y = 0.8
            support.label(text="Support the creator:", icon="FUND")
            support.label(text="open in browser, like & subscribe.")
            col.operator("bvp.open_external", icon="WORLD")
            col.label(text=f"yt-dlp: {deps.ytdlp_version() or 'not found'}")

        box = layout.box()
        box.scale_y = 0.8
        box.label(text="Respect ToS and copyright.", icon="ERROR")
        box.label(text="Use your own, CC, or public-domain content.")


class BVP_PT_panel(_BVPPanelDraw, bpy.types.Panel):
    bl_idname = "BVP_PT_panel"
    bl_space_type = "VIEW_3D"


class BVP_PT_panel_image(_BVPPanelDraw, bpy.types.Panel):
    bl_idname = "BVP_PT_panel_image"
    bl_space_type = "IMAGE_EDITOR"
