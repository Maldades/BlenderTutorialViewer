"""Mounting and playback of the video inside Blender — own clock, no timeline.

Design (v1.5):

- **Video**: the file is loaded as a ``MOVIE`` image datablock and shown in an
  **Image Editor**. A ``bpy.app.timers`` tick drives the displayed frame
  directly via ``image_user.frame_current`` (with ``use_auto_refresh`` off,
  Blender never recomputes it from the scene frame).
- **Audio**: played with Blender's bundled ``aud`` engine, independent of the
  sequencer. The audio position is the master clock the video follows, so A/V
  cannot drift. Without audio (or without ``aud``), a wall clock takes over.
- **The user's scene is untouched**: frame range, FPS, sync mode, timeline and
  VSE stay exactly as they were — you can animate (and even play your own
  animation) while the tutorial keeps playing in its corner.

Earlier versions (≤1.4) played through the scene timeline instead; the strip
sweep and the snapshot *restore* are kept so unloading after an upgrade still
cleans up and puts the scene back.
"""
import time

import bpy

#: Name prefix to identify elements created by this add-on.
STRIP_PREFIX = "BVP_"

#: Scene id-prop that ≤1.4 used for the timeline snapshot (legacy, restore only).
SCENE_STATE_KEY = "bvp_prev_state"
#: Scene id-prop marking that the add-on split an area to create the player.
SPLIT_AREA_KEY = "bvp_split_area"

#: Assumed fps when neither yt-dlp nor Blender can tell (rare).
DEFAULT_FPS = 30.0

#: Interval (s) of the playback clock tick (frame updates + redraw).
_CLOCK_INTERVAL = 1 / 30
#: Refresh the sidebar (time counter) every N ticks (~1 Hz).
_UI_REFRESH_EVERY = 30

#: Interval (s) of the auto-fit monitor.
_AUTOFIT_INTERVAL = 0.25
#: Last known size of each area, keyed by ``area.as_pointer()``.
_autofit_last_sizes = {}

#: Playback state: ``clock`` (PlaybackClock), ``fps``, ``frames``, ``ticks``.
_state = {}

#: Shared aud device (opening one per video would stack audio contexts).
_audio_device = None


# --- Playback clock (pure logic, aud handle injected; see tests) ---

class PlaybackClock:
    """Playback position in seconds. Audio-handle master, wall-clock fallback.

    ``handle`` is an ``aud`` playback handle (anything with a ``position``
    attribute and ``pause()``/``resume()``/``stop()``); when it is absent or
    dies (e.g. the audio device disappears), a monotonic wall clock takes over
    from the last known position. ``monotonic`` is injectable for tests.
    """

    def __init__(self, handle=None, monotonic=None):
        self._handle = handle
        self._mono = monotonic or time.monotonic
        self._paused = False
        self._base = 0.0
        self._mark = self._mono()

    @property
    def paused(self):
        return self._paused

    def position(self):
        if self._handle is not None:
            try:
                return max(0.0, float(self._handle.position))
            except Exception:  # noqa: BLE001 - device gone: wall clock
                self._drop_handle()
        if self._paused:
            return self._base
        return self._base + (self._mono() - self._mark)

    def pause(self):
        if self._paused:
            return
        self._base = self.position()
        self._paused = True
        self._call_handle("pause")

    def resume(self):
        if not self._paused:
            return
        self._mark = self._mono()
        self._paused = False
        self._call_handle("resume")

    def toggle(self):
        if self._paused:
            self.resume()
        else:
            self.pause()

    def seek(self, position):
        position = max(0.0, position)
        self._base = position
        self._mark = self._mono()
        if self._handle is not None:
            try:
                self._handle.position = position
            except Exception:  # noqa: BLE001
                self._drop_handle()

    def set_volume(self, volume):
        if self._handle is None:
            return
        try:
            self._handle.volume = volume
        except Exception:  # noqa: BLE001
            self._drop_handle()

    def stop(self):
        self._base = self.position()
        self._paused = True
        self._call_handle("stop")
        self._handle = None

    def _call_handle(self, method):
        if self._handle is None:
            return
        try:
            getattr(self._handle, method)()
        except Exception:  # noqa: BLE001
            self._drop_handle()

    def _drop_handle(self):
        # Keep time flowing from the wall clock instead.
        self._handle = None
        self._mark = self._mono()


def frame_for_position(position, fps, frame_count):
    """1-based movie frame shown at ``position`` seconds."""
    frame = int(position * (fps or DEFAULT_FPS)) + 1
    return max(1, min(frame_count or 1, frame))


# --- Audio / fps probing (bpy layer) ---

#: Desired audio volume (0.0–1.0); outlives mounts so the user sets it once.
_volume = 1.0


def _open_audio(filepath):
    """Start playing ``filepath`` with aud and return the handle, or ``None``.

    Playback starts immediately (mounting auto-plays). Files without an audio
    track (or a missing/disabled audio device) simply return ``None`` and the
    wall clock drives the video.
    """
    global _audio_device
    try:
        import aud
        if _audio_device is None:
            _audio_device = aud.Device()
        handle = _audio_device.play(aud.Sound(filepath))
        try:
            handle.volume = _volume
        except Exception:  # noqa: BLE001 - keep the handle even so
            pass
        return handle
    except Exception:  # noqa: BLE001 - no aud / no device / no audio track
        return None


def set_volume(fraction):
    """Set the video's audio volume (0.0–1.0). Remembered across mounts."""
    global _volume
    _volume = min(max(0.0, fraction), 1.0)
    clock = _state.get("clock")
    if clock is not None:
        clock.set_volume(_volume)


def probe_fps(filepath):
    """Video fps read via a throwaway MovieClip, or ``None``."""
    try:
        clip = bpy.data.movieclips.load(filepath)
    except Exception:  # noqa: BLE001 - not a movie Blender can read
        return None
    try:
        return clip.fps or None
    finally:
        bpy.data.movieclips.remove(clip)


# --- Legacy (≤1.4) cleanup: sound strips + timeline snapshot restore ---

def _strips(se):
    """Strip collection, compatible with 5.x (``strips``) and 4.x (``sequences``)."""
    if hasattr(se, "strips"):
        return se.strips
    return se.sequences


def restore_scene_state(scene):
    """Restore (and consume) a ≤1.4 timeline snapshot, if present.

    :returns: ``True`` if there was a snapshot to restore.
    """
    state = scene.get(SCENE_STATE_KEY)
    if state is None:
        return False
    # RNA clamps frame_start/frame_end against each other; start-end-start is
    # safe for any combination of old and new ranges.
    scene.frame_start = int(state["frame_start"])
    scene.frame_end = int(state["frame_end"])
    scene.frame_start = int(state["frame_start"])
    scene.frame_current = int(state["frame_current"])
    scene.render.fps = int(state["fps"])
    scene.render.fps_base = float(state["fps_base"])
    scene.sync_mode = str(state["sync_mode"])
    del scene[SCENE_STATE_KEY]
    return True


def clear_video(scene):
    """Remove the images (and any legacy ≤1.4 strips/sounds) this add-on made."""
    se = scene.sequence_editor
    if se is not None:
        strips = _strips(se)
        for strip in list(strips):
            if strip.name.startswith(STRIP_PREFIX):
                strips.remove(strip)
    for image in list(bpy.data.images):
        if image.get("bvp_owned"):
            bpy.data.images.remove(image)
    for sound in list(bpy.data.sounds):
        if sound.get("bvp_owned") and sound.users == 0:
            bpy.data.sounds.remove(sound)


# --- Mount / unmount ---

def add_video(scene, filepath, fps=None, replace=True, audio_filepath=None):
    """Load ``filepath`` as a movie image and start own-clock playback.

    ``audio_filepath``: separate audio file for split downloads; the audio of
    ``filepath`` itself is used when omitted. The scene is NOT modified.

    Returns the movie image datablock.
    """
    if replace:
        clear_video(scene)
    stop_playback()

    image = bpy.data.images.load(filepath, check_existing=False)
    if image.source != "MOVIE":
        # Force movie interpretation (in case the heuristic fails).
        try:
            image.source = "MOVIE"
        except (TypeError, ValueError):
            pass
    image["bvp_owned"] = True

    if not fps:
        fps = probe_fps(filepath)

    handle = _open_audio(audio_filepath or filepath)
    _state.update(
        clock=PlaybackClock(handle),
        fps=float(fps or DEFAULT_FPS),
        frames=max(1, image.frame_duration or 1),
        ticks=0,
    )
    if not bpy.app.timers.is_registered(_clock_tick):
        bpy.app.timers.register(_clock_tick, first_interval=_CLOCK_INTERVAL)
    _ensure_draw_handler()
    return image


def stop_playback():
    """Stop the clock, the audio, the tick timer and the draw handler."""
    clock = _state.get("clock")
    if clock is not None:
        clock.stop()
    _state.clear()
    if bpy.app.timers.is_registered(_clock_tick):
        bpy.app.timers.unregister(_clock_tick)
    _remove_draw_handler()


def unload_video(context):
    """Stop playback, remove everything BVP created and clean the scene.

    :returns: ``True`` if a legacy (≤1.4) timeline snapshot was restored.
    """
    scene = context.scene
    stop_playback()
    stop_autofit_monitor()
    close_player_area(context)
    clear_video(scene)
    return restore_scene_state(scene)


def has_video_state(scene):
    """Whether the add-on has anything to unload in ``scene``."""
    if _state.get("clock") is not None:
        return True
    if scene.get(SCENE_STATE_KEY) is not None:
        return True
    se = scene.sequence_editor
    if se is not None and any(s.name.startswith(STRIP_PREFIX) for s in _strips(se)):
        return True
    return any(i.get("bvp_owned") for i in bpy.data.images)


# --- Playback control (used by the operators/panel) ---

def is_mounted():
    return _state.get("clock") is not None


def is_playing(context=None):
    clock = _state.get("clock")
    return clock is not None and not clock.paused


def toggle_play(context=None, area=None):
    """Play/pause the video clock. Play at the end restarts from 0."""
    clock = _state.get("clock")
    if clock is None:
        return
    if clock.paused and _current_frame() >= _state["frames"]:
        clock.seek(0.0)
    clock.toggle()
    _apply_frame_now()


def seek(delta_seconds):
    """Jump ``delta_seconds`` (negative = back) on the playback clock."""
    clock = _state.get("clock")
    if clock is None:
        return
    duration = _state["frames"] / _state["fps"]
    target = min(max(0.0, clock.position() + delta_seconds), duration)
    clock.seek(target)
    _apply_frame_now()


def seek_fraction(fraction):
    """Scrub to ``fraction`` (0.0–1.0) of the video's own timeline."""
    clock = _state.get("clock")
    if clock is None:
        return
    duration = _state["frames"] / _state["fps"]
    clock.seek(min(max(0.0, fraction), 1.0) * duration)
    _apply_frame_now()


#: True while the tick pushes the playhead slider (blocks the update callback).
_ui_syncing = False


def ui_syncing():
    return _ui_syncing


def _sync_playhead():
    """Reflect the clock position on the panel's playhead slider."""
    global _ui_syncing
    clock = _state.get("clock")
    wm = getattr(bpy.context, "window_manager", None)
    if clock is None or wm is None or not hasattr(wm, "bvp_playhead"):
        return
    duration = _state["frames"] / _state["fps"]
    pct = 100.0 * clock.position() / duration if duration > 0 else 0.0
    _ui_syncing = True
    try:
        wm.bvp_playhead = min(100.0, max(0.0, pct))
    finally:
        _ui_syncing = False


def playback_status():
    """``m:ss / m:ss`` of the current playback, or ``""`` when unmounted."""
    clock = _state.get("clock")
    if clock is None:
        return ""

    def fmt(seconds):
        minutes, secs = divmod(int(max(0.0, seconds)), 60)
        return f"{minutes}:{secs:02d}"

    return f"{fmt(clock.position())} / {fmt(_state['frames'] / _state['fps'])}"


def _current_frame():
    clock = _state["clock"]
    return frame_for_position(clock.position(), _state["fps"], _state["frames"])


def _bvp_image():
    for image in bpy.data.images:
        if image.get("bvp_owned"):
            return image
    return None


def _invalidate_image(image):
    """Make the next draw actually show the new frame.

    The Image Editor keeps drawing a cached buffer when only
    ``image_user.frame_current`` changes (verified live: big seeks showed a
    pixel-identical, stale frame). ``gl_free()`` drops just the GPU textures:
    the editor re-uploads the frame decoded for the new ``framenr`` while the
    decoder state survives — smooth playback. (``buffers_free()`` also
    refreshes, but resets the whole cache: on long h264 videos every frame
    re-decodes from the last keyframe and playback stutters — verified live.)
    """
    try:
        image.gl_free()
    except Exception:  # noqa: BLE001 - fall back to the heavy invalidation
        try:
            image.buffers_free()
        except Exception:  # noqa: BLE001
            pass


def _external_frame():
    """Frame set by something other than us on the player's ``image_user``.

    Note: the frame bar at the bottom of the Image Editor is NOT this — it
    scrubs the SCENE timeline (verified live), which this player ignores by
    design. This catches direct ``frame_current`` writes (e.g. scripts or
    sidebar edits) and lets the tick turn them into a seek instead of
    silently overwriting them ~30×/s.
    """
    applied = _state.get("applied_frame")
    if applied is None:
        return None
    for _win, area in _iter_target_areas():
        current = area.spaces.active.image_user.frame_current
        if abs(current - applied) >= 2:
            return current
    return None


def _show_frame(frame):
    """Set ``frame`` on every player area and force a real redraw."""
    changed = False
    for _win, area in _iter_target_areas():
        iuser = area.spaces.active.image_user
        if iuser.frame_current != frame:
            iuser.frame_current = frame
            changed = True
        if changed:
            area.tag_redraw()
    _state["applied_frame"] = frame
    if changed:
        image = _bvp_image()
        if image is not None:
            _invalidate_image(image)
    return changed


def _apply_frame_now():
    """Push the clock's frame to the player area(s) immediately."""
    try:
        if _state.get("clock") is None:
            return
        _show_frame(_current_frame())
        _sync_playhead()
        _redraw_sidebars()
    except Exception:  # noqa: BLE001 - UI refresh is best-effort
        pass


#: Handle of the per-draw callback (see :func:`_on_player_draw`).
_draw_handle = None


def _on_player_draw():
    """Runs right before a player area draws: show the clock's frame NOW and,
    while playing, request the next redraw.

    This makes playback self-sustaining and independent of timer→redraw
    plumbing: on macOS, ``tag_redraw`` from a ``bpy.app.timers`` callback does
    not reliably wake the display loop (the video only advanced when resizing
    forced redraws), while a redraw requested from inside a draw always
    schedules the next one. Evaluating the frame at draw time also means zero
    added latency.
    """
    try:
        clock = _state.get("clock")
        space = getattr(bpy.context, "space_data", None)
        image = getattr(space, "image", None) if space is not None else None
        if clock is None or image is None or not image.get("bvp_owned"):
            return
        iuser = space.image_user
        applied = _state.get("applied_frame")
        if applied is not None and abs(iuser.frame_current - applied) >= 2:
            # Foreign frame_current write (script/sidebar): follow it.
            clock.seek(max(0, iuser.frame_current - 1) / _state["fps"])
        frame = _current_frame()
        if iuser.frame_current != frame:
            iuser.frame_current = frame
            _state["applied_frame"] = frame
            _invalidate_image(image)
        if not clock.paused:
            area = getattr(bpy.context, "area", None)
            if area is not None:
                area.tag_redraw()
    except Exception:  # noqa: BLE001 - a draw callback must never raise
        pass


def _ensure_draw_handler():
    global _draw_handle
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceImageEditor.draw_handler_add(
            _on_player_draw, (), "WINDOW", "PRE_VIEW"
        )


def _remove_draw_handler():
    global _draw_handle
    if _draw_handle is not None:
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(_draw_handle, "WINDOW")
        except Exception:  # noqa: BLE001 - already gone
            pass
        _draw_handle = None


def _clock_tick():
    """Timer: follow the clock, update the shown frame, hold at the end.

    The draw handler (:func:`_on_player_draw`) is what keeps the video area
    repainting while playing; this timer complements it: end-of-video pause,
    playhead/sidebar sync, and frame updates on platforms where timers alone
    suffice. Never dies: any unexpected error is printed once and the timer
    keeps going (a dead timer would freeze those duties silently).
    """
    clock = _state.get("clock")
    if clock is None:
        return None  # unmounted: stop the timer
    try:
        # A foreign frame_current write (script/sidebar) becomes a seek.
        external = _external_frame()
        if external is not None:
            clock.seek(max(0, external - 1) / _state["fps"])
        frame = _current_frame()
        if frame >= _state["frames"] and not clock.paused:
            clock.pause()  # end of video: hold the last frame (Play restarts)
        _show_frame(frame)
        _state["ticks"] += 1
        if _state["ticks"] % _UI_REFRESH_EVERY == 0:
            _sync_playhead()
            _redraw_sidebars()
    except Exception:  # noqa: BLE001 - keep the player alive
        if not _state.get("tick_error_logged"):
            _state["tick_error_logged"] = True
            import traceback
            print("[blender_video_player] error in playback tick:")
            traceback.print_exc()
    return _CLOCK_INTERVAL


def _redraw_sidebars():
    """Refresh the N-panels (time counter, play/pause icon, playhead)."""
    wm = bpy.context.window_manager
    if wm is None:
        return
    for win in wm.windows:
        screen = win.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type in {"VIEW_3D", "IMAGE_EDITOR"}:
                for region in area.regions:
                    if region.type == "UI":
                        region.tag_redraw()


# --- Interface (requires a window; tested live) ---

def get_image_editor_area(screen):
    for area in screen.areas:
        if area.type == "IMAGE_EDITOR":
            return area
    return None


def open_player_area(context, image):
    """Open (or reuse) an Image Editor showing ``image``.

    If there is none, split the largest area. Returns the area, or ``None`` in
    background mode (no screen).
    """
    screen = getattr(context, "screen", None)
    if screen is None:
        return None

    area = get_image_editor_area(screen)
    if area is None:
        biggest = max(screen.areas, key=lambda a: a.width * a.height)
        before = set(screen.areas)
        with context.temp_override(area=biggest):
            bpy.ops.screen.area_split(direction="VERTICAL", factor=0.5)
        new_areas = [a for a in screen.areas if a not in before]
        area = new_areas[0] if new_areas else biggest
        area.type = "IMAGE_EDITOR"
        # Remember that WE created this area, so unload can close it.
        context.scene[SPLIT_AREA_KEY] = True

    space = area.spaces.active
    space.image = image
    image_user = space.image_user
    image_user.frame_duration = image.frame_duration or 1
    image_user.frame_start = 1
    image_user.frame_offset = 0
    image_user.use_cyclic = False
    # The add-on's clock drives the frame; Blender must not recompute it from
    # the scene frame (this is what frees the user's timeline).
    image_user.use_auto_refresh = False
    image_user.frame_current = 1
    area.tag_redraw()
    return area


def close_player_area(context):
    """Close the Image Editor(s) the add-on split off, if any. Best-effort.

    Only closes areas when :data:`SPLIT_AREA_KEY` says the add-on created one;
    a pre-existing Image Editor reused as player is left open.
    """
    scene = context.scene
    if scene.get(SPLIT_AREA_KEY) is None:
        return
    for win, area in list(_iter_target_areas()):
        try:
            with context.temp_override(window=win, area=area):
                bpy.ops.screen.area_close()
        except Exception:  # noqa: BLE001 - layout-dependent, best-effort
            pass
    del scene[SPLIT_AREA_KEY]


# --- Auto-fit on load and on area resize ---

def _iter_target_areas():
    """Yield ``(window, area)`` for each Image Editor showing our image."""
    wm = bpy.context.window_manager
    if wm is None:
        return
    for win in wm.windows:
        screen = win.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "IMAGE_EDITOR":
                continue
            space = area.spaces.active
            image = getattr(space, "image", None)
            if image is not None and image.get("bvp_owned"):
                yield win, area


def fit_view(area=None, window=None):
    """Fit the video in the add-on's Image Editor(s). Best-effort."""
    context = bpy.context
    if area is not None:
        pairs = [(window or getattr(context, "window", None), area)]
    else:
        pairs = list(_iter_target_areas())
    for win, target in pairs:
        if win is None or target is None:
            continue
        region = next((r for r in target.regions if r.type == "WINDOW"), None)
        if region is None:
            continue
        try:
            with context.temp_override(window=win, area=target, region=region):
                bpy.ops.image.view_all(fit_view=True)
        except Exception:  # noqa: BLE001 - best-effort
            pass


def _autofit_tick():
    """Poller: re-fit when the player area size changes."""
    found = False
    for win, area in _iter_target_areas():
        found = True
        key = area.as_pointer()
        size = (area.width, area.height)
        if _autofit_last_sizes.get(key) != size:
            _autofit_last_sizes[key] = size
            fit_view(area=area, window=win)
    if not found:
        _autofit_last_sizes.clear()
        return None  # no player: stop the monitor
    return _AUTOFIT_INTERVAL


def start_autofit_monitor():
    if not bpy.app.timers.is_registered(_autofit_tick):
        _autofit_last_sizes.clear()
        bpy.app.timers.register(_autofit_tick, first_interval=0.1)


def stop_autofit_monitor():
    if bpy.app.timers.is_registered(_autofit_tick):
        bpy.app.timers.unregister(_autofit_tick)
    _autofit_last_sizes.clear()
