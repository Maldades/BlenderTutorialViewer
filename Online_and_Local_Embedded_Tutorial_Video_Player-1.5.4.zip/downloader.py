"""Downloading remote videos with yt-dlp — no ffmpeg required.

Pure logic, no ``bpy`` dependency. ``yt_dlp`` is imported lazily in
:func:`get_youtube_dl_class` so this module is importable (and testable with a
double) even when yt-dlp is not installed.

Strategy, in order:

1. **merged** — only when ``ffmpeg_location`` is passed: best video+audio
   merged into a single mp4 by ffmpeg (the nicest file to keep).
2. **split** — no ffmpeg: the video-only and audio-only streams are downloaded
   as TWO files (yt-dlp needs no ffmpeg for that) and the player mounts them
   separately — movie image + sound strip — which is what it does anyway.
   This keeps 1080p working on Windows/macOS/Linux without bundling or
   installing ffmpeg.
3. **single** — sites without separate streams (direct links, etc.): one
   already-muxed file. On YouTube this caps at ~360p, hence 1 and 2.

h264 (avc1) at ≤1080p is preferred so Blender's decoder always copes.
"""
import os

#: One file, merged by ffmpeg (only used when ffmpeg is available).
FORMAT_MERGED = (
    "bestvideo[vcodec^=avc1][height<=?1080]+bestaudio[ext=m4a]"
    "/bestvideo[ext=mp4][height<=?1080]+bestaudio[ext=m4a]"
    "/best[ext=mp4]/best"
)
#: Two files (video-only + audio-only), downloadable without ffmpeg.
FORMAT_SPLIT = (
    "bestvideo[vcodec^=avc1][height<=?1080]"
    "/bestvideo[ext=mp4][height<=?1080]"
    "/bestvideo"
    ",bestaudio[ext=m4a]/bestaudio"
)
#: One already-muxed file (fallback for sites without separate streams).
FORMAT_SINGLE = "best[ext=mp4]/best"

OUTTMPL = "%(title)s [%(id)s].%(ext)s"
#: Split downloads keep the format id in the name ('X.f137.mp4' + 'X.f140.m4a')
#: so the two files never collide and can be re-associated later
#: (see ``source.find_sibling_audio``).
OUTTMPL_SPLIT = "%(title)s [%(id)s].f%(format_id)s.%(ext)s"


class DependencyError(RuntimeError):
    """yt-dlp is not available."""


def get_youtube_dl_class():
    """Return the ``yt_dlp.YoutubeDL`` class or raise :class:`DependencyError`.

    Kept in its own function so it can be replaced by a double in tests and so
    the import failure is explicit.
    """
    try:
        import yt_dlp  # noqa: WPS433 (lazy import on purpose)
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise DependencyError("yt-dlp is not available.") from exc
    return yt_dlp.YoutubeDL


def _is_format_error(exc):
    """True for yt-dlp's 'Requested format is not available' error."""
    return "requested format is not available" in str(exc).lower()


def _scale_split_hook(hook):
    """Map per-file progress of the two split downloads onto one 0–100 bar."""
    state = {"done": 0}

    def wrapped(data):
        status = data.get("status")
        if status == "downloading":
            total = data.get("total_bytes") or data.get("total_bytes_estimate")
            if total:
                pct = (state["done"] + data.get("downloaded_bytes", 0) / total) * 50.0
                hook(
                    {
                        "status": "downloading",
                        "downloaded_bytes": pct,
                        "total_bytes": 100.0,
                    }
                )
        elif status == "finished":
            state["done"] += 1
            if state["done"] >= 2:
                hook({"status": "finished"})
            else:
                hook(
                    {
                        "status": "downloading",
                        "downloaded_bytes": 50.0,
                        "total_bytes": 100.0,
                    }
                )

    return wrapped


def build_ydl_opts(out_dir, progress_hook=None, ffmpeg_location=None, fmt=None,
                   outtmpl=OUTTMPL):
    """Build the options dict for ``YoutubeDL``.

    ``fmt`` defaults to :data:`FORMAT_MERGED` when an ``ffmpeg_location`` is
    given (ffmpeg merges video+audio into one mp4) and to :data:`FORMAT_SPLIT`
    otherwise (two files, no merge step → no ffmpeg needed).
    """
    if fmt is None:
        fmt = FORMAT_MERGED if ffmpeg_location else FORMAT_SPLIT
    opts = {
        "format": fmt,
        "outtmpl": os.path.join(out_dir, outtmpl),
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
    }
    if ffmpeg_location:
        opts["merge_output_format"] = "mp4"
        opts["ffmpeg_location"] = ffmpeg_location
    if progress_hook is not None:
        opts["progress_hooks"] = [progress_hook]
    return opts


def _first_entry(info):
    """If ``info`` is a playlist, return the first entry."""
    entries = info.get("entries") if isinstance(info, dict) else None
    if entries:
        return entries[0]
    return info


def _resolve_filepath(info, ydl):
    """Get the final path of a single-file (merged or muxed) download."""
    downloads = info.get("requested_downloads")
    if downloads:
        path = downloads[0].get("filepath")
        if path:
            return path
    # Fallback: rebuild the name from the template.
    return ydl.prepare_filename(info)


def _split_paths(info, ydl):
    """``(video_path, audio_path, video_fps)`` from a split download."""
    video = audio = fps = None
    for entry in info.get("requested_downloads") or []:
        path = entry.get("filepath")
        if not path:
            continue
        if entry.get("vcodec") not in (None, "none"):
            if video is None:
                video, fps = path, entry.get("fps")
        elif audio is None:
            audio = path
    if video is None:  # defensive: never happened in testing
        video = _resolve_filepath(info, ydl)
    return video, audio, fps


def _result(info, filepath, audio_filepath, fps):
    return {
        "filepath": filepath,
        "audio_filepath": audio_filepath,
        "title": info.get("title"),
        "fps": fps,
        "duration": info.get("duration"),
    }


def download(url, out_dir, progress_hook=None, ffmpeg_location=None):
    """Download ``url`` into ``out_dir`` and return paths + metadata.

    :returns: dict with ``filepath`` (video), ``audio_filepath`` (separate
        audio file, or ``None`` when the video file already carries its
        audio), ``title``, ``fps`` and ``duration``.
    :raises DependencyError: if yt-dlp is not available.
    """
    youtube_dl_class = get_youtube_dl_class()

    if ffmpeg_location:
        opts = build_ydl_opts(out_dir, progress_hook, ffmpeg_location,
                              fmt=FORMAT_MERGED)
        with youtube_dl_class(opts) as ydl:
            info = _first_entry(ydl.extract_info(url, download=True))
            return _result(info, _resolve_filepath(info, ydl), None,
                           info.get("fps"))

    hook = _scale_split_hook(progress_hook) if progress_hook else None
    opts = build_ydl_opts(out_dir, hook, fmt=FORMAT_SPLIT,
                          outtmpl=OUTTMPL_SPLIT)
    try:
        with youtube_dl_class(opts) as ydl:
            info = _first_entry(ydl.extract_info(url, download=True))
            video, audio, fps = _split_paths(info, ydl)
            return _result(info, video, audio, fps or info.get("fps"))
    except Exception as exc:  # noqa: BLE001 - filtered right below
        if not _is_format_error(exc):
            raise

    # The site has no separate video/audio streams: one muxed file.
    opts = build_ydl_opts(out_dir, progress_hook, fmt=FORMAT_SINGLE)
    with youtube_dl_class(opts) as ydl:
        info = _first_entry(ydl.extract_info(url, download=True))
        return _result(info, _resolve_filepath(info, ydl), None,
                       info.get("fps"))
