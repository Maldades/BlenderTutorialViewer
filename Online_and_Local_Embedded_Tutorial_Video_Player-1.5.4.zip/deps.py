"""Dependency access. Everything ships bundled — nothing installs at runtime.

The Blender extensions platform forbids installing packages at runtime, so the
only dependency, ``yt_dlp`` (pure-python), ships as a wheel declared in
``blender_manifest.toml``; Blender puts it on ``sys.path`` when the extension
is enabled. As a development fallback (e.g. running from a symlinked source
tree), the bundled ``.whl`` is added to ``sys.path`` manually (pure-python
wheels are importable via zipimport).

ffmpeg is OPTIONAL: downloads work without it (see ``downloader``). When a
system ffmpeg exists, it is used to merge video+audio into a single file.

Does not import ``bpy``: only the standard library.
"""
import importlib
import os
import shutil
import sys

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
WHEELS_DIR = os.path.join(ADDON_DIR, "wheels")

_UNSET = object()
#: Cache of the ffmpeg path (avoids recomputing on every panel redraw).
_ffmpeg_path = _UNSET


def _candidate_paths():
    paths = []
    if os.path.isdir(WHEELS_DIR):
        paths.append(WHEELS_DIR)
        for name in sorted(os.listdir(WHEELS_DIR)):
            if name.endswith(".whl"):
                paths.append(os.path.join(WHEELS_DIR, name))
    return paths


def _add_local_paths():
    for path in _candidate_paths():
        if path not in sys.path:
            sys.path.insert(0, path)


def ensure_ytdlp():
    """Return the importable ``yt_dlp`` module, or ``None`` if not available."""
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        pass
    _add_local_paths()
    importlib.invalidate_caches()
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        return None


def ytdlp_version():
    module = ensure_ytdlp()
    if module is None:
        return None
    try:
        return module.version.__version__
    except AttributeError:
        return "?"


def find_ffmpeg(refresh=False):
    """Path to a system ffmpeg, or ``None``. Cached.

    ffmpeg is optional: with it, downloads merge into a single file; without
    it, the downloader falls back to split video+audio files.
    """
    global _ffmpeg_path
    if _ffmpeg_path is not _UNSET and not refresh:
        return _ffmpeg_path
    _ffmpeg_path = shutil.which("ffmpeg")
    return _ffmpeg_path
