"""Video player (internet + local) inside Blender.

Blender 4.2+ extension (metadata in ``blender_manifest.toml``).
Registers a panel under VIEW_3D > N-panel > "Video" tab.
"""
import bpy

from . import operators, panel, player, properties

try:  # EXPERIMENTAL prototype; excluded from shipped builds (see manifest).
    from . import livetut
except Exception:  # noqa: BLE001 - the add-on must work without it
    livetut = None

classes = (
    properties.BVPProperties,
    operators.BVP_OT_load_video,
    operators.BVP_OT_play_pause,
    operators.BVP_OT_seek,
    operators.BVP_OT_unload_video,
    operators.BVP_OT_open_external,
    panel.BVP_PT_panel,
    panel.BVP_PT_panel_image,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bvp = bpy.props.PointerProperty(type=properties.BVPProperties)
    properties.register_wm_props()
    if livetut is not None:
        livetut.register()


def unregister():
    if livetut is not None:
        livetut.unregister()
    player.stop_playback()
    player.stop_autofit_monitor()
    properties.unregister_wm_props()
    if hasattr(bpy.types.Scene, "bvp"):
        del bpy.types.Scene.bvp
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
