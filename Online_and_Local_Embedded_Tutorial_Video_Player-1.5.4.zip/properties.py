"""Add-on properties: ``Scene.bvp`` (inputs) and the runtime playhead/volume.

The playhead and volume sliders live on ``WindowManager`` so dragging them
(the playhead syncs ~1×/s while watching) never marks the .blend as modified.
"""
import bpy
from bpy.props import EnumProperty, FloatProperty, StringProperty

from . import player


def _playhead_update(self, _context):
    if player.ui_syncing():
        return  # the tick is reflecting the clock, not the user scrubbing
    player.seek_fraction(self.bvp_playhead / 100.0)


def _volume_update(self, _context):
    player.set_volume(self.bvp_volume / 100.0)


def register_wm_props():
    bpy.types.WindowManager.bvp_playhead = FloatProperty(
        name="Position",
        description="Position in the video (drag to scrub)",
        min=0.0, max=100.0, default=0.0,
        subtype="PERCENTAGE",
        update=_playhead_update,
    )
    bpy.types.WindowManager.bvp_volume = FloatProperty(
        name="Volume",
        description="Audio volume of the video",
        min=0.0, max=100.0, default=100.0,
        subtype="PERCENTAGE",
        update=_volume_update,
    )


def unregister_wm_props():
    for name in ("bvp_playhead", "bvp_volume"):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)


class BVPProperties(bpy.types.PropertyGroup):
    source_type: EnumProperty(
        name="Source",
        items=[
            ("URL", "Internet URL", "A YouTube or other site video, or a direct link"),
            ("LOCAL", "Local file", "A video file on your computer"),
        ],
        default="URL",
    )
    url: StringProperty(
        name="URL",
        description="Video link (YouTube, Vimeo, direct link, etc.)",
        default="",
    )
    local_path: StringProperty(
        name="File",
        description="Path to a local video file",
        subtype="FILE_PATH",
        default="",
    )
    status: StringProperty(name="Status", default="")
    progress: FloatProperty(
        name="Progress", default=0.0, min=0.0, max=100.0, subtype="PERCENTAGE"
    )
    resolved_filepath: StringProperty(default="")
